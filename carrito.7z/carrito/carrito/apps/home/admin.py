from django.contrib import admin
from carrito.apps.home.models import userProfile

admin.site.register(userProfile)