from django.shortcuts import render

from store.models import Product
from store.models import Cart, CartItem

from django.http import HttpResponseRedirect
from django.urls import reverse

def store(request): 
    products = Product.objects.all()
    context = {
        'products': products
    } 
    return render(request, 'store/store.html', context)

def str(self): return self.id

def cart(request):
# Esta función permite mostrar el carrito de compras
    try:
        cart_id = request.session['cart_id']
    except: 
        cart_id = None
    if cart_id:
        cart = Cart.objects.get(id=cart_id)
        context = {"cart": cart}
    else:
        empty_message= "Su Carrito está Vacío. Por favor continúe efectuando sus compras..."
        context = {"empty": True, "empty_message": empty_message}       
    return render(request, 'store/cart.html', context)


def update_cart(request,pk, qty):
# Esta función permite ingresar el producto seleccionado en el carrito de compras
    request.session.set_expiry(12000)
    # scart = Cart.objects.all()[0]

    # Get cart id of current sesion
    # Create a new cart id if there isn't any
    try:
        cart_id = request.session['cart_id']
    except:
        # create cart id if it does not exist
        new_cart = Cart()
        new_cart.save()
        request.session['cart_id'] = new_cart.id
        cart_id = new_cart.id
    try:       
        qty= request.GET.get("qty")     
        update_qty=True  
    except:      
        qty=None      
        update_qty=False

# Evaluar los valores de la variable qty
    if update_qty and qty:    
        if int(qty) <=0:
            cart_id.delete()    
    else:       
        cart_id.quantity = qty       
        cart_id.save()

    # Get list of all products in the current  cart
    cart = Cart.objects.get(id=cart_id)

    # Verify if there is already an article equal to the one passed
    # Si lo está se borra y si no se agrega
    try:
        product = Product.objects.get(pk=pk)
    except Product.DoesNotExist:
        pass
    except:
        pass

    cart_item, created = CartItem.objects.get_or_create(product=product)
    if created:
        print("Item ingresado")
        if qty <= 0:         
            cart_item.delete()    
        else:         
            cart_item.quantity = qty         
            cart_item.save()
    if not cart_item in cart.items.all():
        cart.items.add(cart_item)
    else:
        cart.items.remove(cart_item)

    new_total = 0.00
    for item in cart.item_set.all():
        new_total += float(item.product.price)

    request.session['total_items'] = cart.item_set.count()
    cart.total = new_total
    cart.save()


    return HttpResponseRedirect(reverse("cart"))