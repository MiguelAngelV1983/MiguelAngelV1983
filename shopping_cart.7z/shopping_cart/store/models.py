from django.db import models

class Product(models.Model): 
   image_path = models.CharField(max_length=200)  
   title = models.CharField(max_length=50)  
   description = models.TextField()  
   price = models.DecimalField(decimal_places=2, max_digits=100)

   def __str__(self):
      return self.title


class CartItem(models.Model):
   product = models.ForeignKey(Product, null=True, blank=True, on_delete= models.CASCADE)
   quantity = models.IntegerField(default=1)

   def __str__(self):
      return self.product.title

class Cart(models.Model):
   items = models.ManyToManyField(CartItem)
   total = models.DecimalField(max_digits=100, decimal_places=2, default=0.00)

   def __str__(self):
      return "Cart id: %s" %(self.id)