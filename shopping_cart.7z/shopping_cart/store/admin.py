# Register your models here.

from django.contrib import admin 
from store.models import Product 
from .models import Cart
from django.contrib.auth.models import Group


class ProductAdmin(admin.ModelAdmin):
    search_fields = ['title']
    list_display = ['image_path', 'title', 'description', 'price']
    list_editable = ['price']
    list_filter = ['price']
    class Meta:
        model = Product
        
admin.site.register(Product, ProductAdmin)

admin.site.register(Product)

class ProductAdmin(admin.ModelAdmin):
    search_fields = ['title']
    list_display = ['image_path', 'title', 'description', 'price']
    list_editable = ['price']
    list_filter = ['price']

admin.site.register(Product, ProductAdmin)

admin.site.register(Cart)

admin.site.site_header = "Shopping Cart Administration"
