#RECUPERACION ACTIVIDAD 2 PROGRAMACION AVANZADA
#EDITOR DE TAGS MP3
#ALUMNO: MIGUEL A. VALVERDE GONZALEZ


#Importamos las librerias necesarias


import os
import sys
from functools import partial


from PyQt6.QtWidgets import QComboBox
from PyQt6.QtWidgets import QLineEdit
from PyQt6.QtWidgets import QFormLayout
from PyQt6.QtWidgets import QPushButton
from PyQt6.QtWidgets import QVBoxLayout
from PyQt6.QtWidgets import QApplication
from PyQt6.QtWidgets import QMainWindow
from PyQt6.QtWidgets import QWidget
from PyQt6.QtWidgets import QLabel

import eyed3
from eyed3.core import AudioFile

#crear la lista para cargarla
playlist = []

# Asignacion del path a la carpeta que contiene los ficheros mp3

Files_mp3 = os.path.abspath(os.getcwd())

#Lectura de la carpeta
with os.scandir(Files_mp3) as entries:
    for entry in entries:
        if entry.is_file():
            playlist.append(entry.name)

#Creacion de la clase principal
class View(QMainWindow):
    def __init__(self):
        super().__init__()

#configuracion y creacion de los elementos de la ventana
        self.setWindowTitle('Editor de Tags MP3')

        self._central_widget = QWidget(self)
        self.setCentralWidget(self._central_widget)
        
        self.setMinimumSize(350, 200)
        
        self.layout_principal = QVBoxLayout()
        self._central_widget.setLayout(self.layout_principal)

        self.Select_song = QLabel("Seleccione una pista para editarla:")
        self.layout_principal.addWidget(self.Select_song)
        
        #Carga el combobox con los archivos del directorio a utilizar 
        self.cmb_songs = QComboBox()
        for i in range(len(playlist)):
            self.cmb_songs.addItem(playlist[i])
        
        self.layout_principal.addWidget(self.cmb_songs)

        self.title = QLineEdit()
        self.artist = QLineEdit()
        self.album = QLineEdit()
        self.album_artist = QLineEdit()

        self.form_edicion = QFormLayout()
        self.form_edicion.addRow('Título:', self.title)
        self.form_edicion.addRow('Artista', self.artist)
        self.form_edicion.addRow('Album:', self.album)
        self.form_edicion.addRow('Album artist:', self.album_artist)
        self.layout_principal.addLayout(self.form_edicion)

        self.Btn_Save_Changes = QPushButton("Guardar")
        self.layout_principal.addWidget(self.Btn_Save_Changes)

#crear la clase model
class Model():

    def __init__(self):
        
        self.audiofile = AudioFile
        
    def Load_song(self, view):
        self._view = view
        cancion = self._view.cmb_songs.currentText()
        self.audiofile = eyed3.load(Files_mp3/{cancion})
        
        #Cargamos archivos sin tags especificados 
        if self.audiofile.tag.title == None:
            self.audiofile.tag.title = "Vacío"
            self._view.title.setText(self.audiofile.tag.title) 
        else:
            self._view.title.setText(self.audiofile.tag.title) 
        
        if self.audiofile.tag.artist == None:
            self.audiofile.tag.artist = "Vacío"
            self._view.artist.setText(self.audiofile.tag.artist) 
        else:
            self._view.artist.setText(self.audiofile.tag.artist) 
        
        if self.audiofile.tag.album == None:
            self.audiofile.tag.album = "Vacío"
            self._view.album.setText(self.audiofile.tag.album) 
        else:
            self._view.album.setText(self.audiofile.tag.album) 
        
        if self.audiofile.tag.album_artist == None:
            self.audiofile.tag.album_artist = "Vacío"
            self._view.album_artist.setText(self.audiofile.tag.album_artist) 
        else:
            self._view.album_artist.setText(self.audiofile.tag.album_artist) 

    def Save_song(self, view):
        self._view = view
        self.audiofile.tag.title = self._view.title.text()
        self.audiofile.tag.artist = self._view.artist.text()
        self.audiofile.tag.album = self._view.album.text()
        self.audiofile.tag.album_artist = self._view.album_artist.text()
        self.audiofile.tag.save()

class Controller():
    def __init__(self, view, model):
        self._view = view
        self._model = model       
        
        self._model.Load_song(self._view)
        self._view.cmb_songs.activated.connect(partial(self._model.Load_song, self._view))
        
        self._model.Save_song(self._view)
        self._view.Btn_Save_Changes.clicked.connect(partial(self._model.Save_song, self._view))


def main():
    app = QApplication(sys.argv)

    view = View()  
    model = Model()
    controller = Controller(view, model)

    view.show()

    sys.exit(app.exec())

if __name__ == '__main__':
    main()